package app.webm4chan

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val ctx = LocalContext.current
            val dark = isSystemInDarkTheme()
            // Dynamic colors need Android 12+; minSdk is 29.
            val scheme = when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
                    if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
                dark -> darkColorScheme()
                else -> lightColorScheme()
            }
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

private val presets = listOf("4 MB" to 4096, "6 MB (/wsg/)" to 6144, "Custom" to -1)

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val view = LocalView.current

    var uri by remember { mutableStateOf<Uri?>(null) }
    var name by remember { mutableStateOf("") }
    var info by remember { mutableStateOf<SourceInfo?>(null) }
    var probeError by remember { mutableStateOf<String?>(null) }

    var presetIdx by remember { mutableIntStateOf(0) }
    var customMb by remember { mutableStateOf("4") }
    var removeAudio by remember { mutableStateOf(true) }

    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var status by remember { mutableStateOf("") }
    var resultMessage by remember { mutableStateOf<String?>(null) }
    var savedUri by remember { mutableStateOf<Uri?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }

    view.keepScreenOn = busy

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
        if (picked != null) {
            uri = picked
            name = Converter.displayName(ctx, picked)
            info = null
            probeError = null
            resultMessage = null
            savedUri = null
            scope.launch {
                val i = Converter.probe(ctx, picked)
                info = i
                if (i == null) probeError = "Couldn't read this video."
            }
        }
    }

    val limitKb: Int = if (presets[presetIdx].second > 0) presets[presetIdx].second
    else ((customMb.toDoubleOrNull() ?: 0.0) * 1024).toInt()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("WebM for 4chan", style = MaterialTheme.typography.headlineMedium)

        Button(onClick = { picker.launch(arrayOf("video/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text(if (uri == null) "Choose video" else "Choose another video")
        }

        if (uri != null) {
            Text(name, style = MaterialTheme.typography.titleSmall)
            val i = info
            when {
                probeError != null -> Text(probeError!!, color = MaterialTheme.colorScheme.error)
                i == null -> Text("Reading video…")
                else -> {
                    val len = String.format(Locale.US, "%.1f", i.durationSec)
                    Text("${i.width}×${i.height}, ${len}s, ${if (i.hasAudio) "has audio" else "no audio"}")
                    if (i.durationSec > Converter.DEFAULT_MAX_DURATION_SEC) {
                        Text(
                            "Longer than ${Converter.DEFAULT_MAX_DURATION_SEC}s: it will be cut to the first ${Converter.DEFAULT_MAX_DURATION_SEC}s.",
                            color = MaterialTheme.colorScheme.tertiary
                        )
                    }
                }
            }
        }

        Text("Size limit", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            presets.forEachIndexed { idx, (label, _) ->
                FilterChip(selected = presetIdx == idx, onClick = { presetIdx = idx }, label = { Text(label) }, enabled = !busy)
            }
        }
        if (presets[presetIdx].second < 0) {
            OutlinedTextField(
                value = customMb,
                onValueChange = { customMb = it },
                label = { Text("Limit in MB") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                enabled = !busy,
            )
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("Remove audio", style = MaterialTheme.typography.titleSmall)
                Text(
                    if (removeAudio) "Output has no sound; the space goes to video quality."
                    else "Keeps sound (about 64 kbps). Only /wsg/ and /gif/ accept audio.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Switch(checked = removeAudio, onCheckedChange = { removeAudio = it }, enabled = !busy)
        }

        val canGo = uri != null && info != null && limitKb >= 256 && !busy
        Button(
            onClick = {
                val u = uri ?: return@Button
                val i = info ?: return@Button
                resultMessage = null
                savedUri = null
                busy = true
                progress = 0f
                status = "Starting…"
                job = scope.launch {
                    val res = Converter.convert(
                        ctx, u, i,
                        Settings(limitKb * 1024L, Converter.DEFAULT_MAX_DURATION_SEC, !removeAudio),
                    ) { p, s -> progress = p; status = s }

                    when (res) {
                        is ConvertResult.Ok -> {
                            val base = name.substringBeforeLast('.', name)
                            val saved = withContext(Dispatchers.IO) {
                                Converter.saveToDownloads(ctx, res.file, "$base.webm")
                            }
                            savedUri = saved
                            val mb = String.format(Locale.US, "%.2f", res.bytes / 1048576.0)
                            resultMessage = buildString {
                                append("Done: $mb MB, ${res.height}p, ${res.videoKbps} kbps video.\n")
                                append(if (saved != null) "Saved to Downloads/WebM4chan/$base.webm" else "Couldn't save to Downloads.")
                                if (res.trimmed) append("\nCut to ${Converter.DEFAULT_MAX_DURATION_SEC}s.")
                                if (res.audioDropped) append("\nSource had no audio.")
                            }
                        }
                        is ConvertResult.Fail -> resultMessage = res.message
                        ConvertResult.Cancelled -> resultMessage = "Cancelled."
                    }
                    busy = false
                }
            },
            enabled = canGo,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Convert") }

        if (busy) {
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            Text(status, style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { Converter.cancel(); job?.cancel() }, modifier = Modifier.fillMaxWidth()) {
                Text("Cancel")
            }
            Text("Keep the app open while converting.", style = MaterialTheme.typography.bodySmall)
        }

        resultMessage?.let { Text(it) }

        savedUri?.let { s ->
            OutlinedButton(
                onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "video/webm"
                        putExtra(Intent.EXTRA_STREAM, s)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    ctx.startActivity(Intent.createChooser(send, "Share webm"))
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Share") }
        }
        Spacer(Modifier.height(8.dp))
    }
}
